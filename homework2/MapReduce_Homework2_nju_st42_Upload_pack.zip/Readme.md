# Readme - MapReduce Homework 2
> nju_st 42
> 洪亮(181240019), 孙舒禺(181840204), 曾许曌秋(181240004)
> 18匡院数理 NJU

## Source Code
./InvertedIndex-1.0.0/src/MainClass.java

## Jar package
./InvertedIndex-1.0.0/out/artifacts/InvertedIndex-1.1.1.jar

## 运行方式
hadoop jar /Path/To/Jar/InvertedIndex-1.1.1.jar MainClass <inputpath> <outputpath>

## Report
./MapReduce_Homework2_report.pdf